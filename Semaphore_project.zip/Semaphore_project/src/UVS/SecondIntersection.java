package UVS;
import Components.Activation;
import Components.Condition;
import Components.GuardMapping;
import Components.PetriNet;
import Components.PetriNetWindow;
import Components.PetriTransition;
import DataObjects.DataCar;
import DataObjects.DataCarQueue;
import DataObjects.DataString;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

public class SecondIntersection {
    public static void main(String[] args) {

        //--------------------------------------------------------------------
        //-------------------------------Lane1--------------------------------
        //--------------------------------------------------------------------

        PetriNet pn = new PetriNet();
        pn.PetriNetName = "Main Petri";
        pn.NetworkPort = 1081;

        DataCar p_a3 = new DataCar();
        p_a3.SetName("p_a3");
        pn.PlaceList.add(p_a3);

        DataCar p_b3 = new DataCar();
        p_b3.SetName("p_b3");
        pn.PlaceList.add(p_b3);

        DataCar p_c7 = new DataCar();
        p_c7.SetName("p_c7");
        pn.PlaceList.add(p_c7);

        DataCar p_c8 = new DataCar();
        p_c8.SetName("p_c8");
        pn.PlaceList.add(p_c8);

        DataCar p_c9 = new DataCar();
        p_c9.SetName("p_c9");
        pn.PlaceList.add(p_c9);

        DataCar p_c10 = new DataCar();
        p_c10.SetName("p_c10");
        pn.PlaceList.add(p_c10);


        DataCarQueue p_xx3 = new DataCarQueue();
        p_xx3.Value.Size = 3;
        p_xx3.SetName("p_xx3");
        pn.PlaceList.add(p_xx3);


//		DataString p3 = new DataString();
//		p3.SetName("P_TL1");
//		pn.PlaceList.add(p3);

        DataString full = new DataString();
        full.SetName("full");
        full.SetValue("full");
        pn.ConstantPlaceList.add(full);


//		DataString green= new DataString();
//		green.SetName("green");
//		green.SetValue("green");
//		green.Printable= false;
//		pn.ConstantPlaceList.add(green);

        // T_U7 ------------------------------------------------
        PetriTransition t_u7 = new PetriTransition(pn);
        t_u7.TransitionName = "t_u7";
        t_u7.InputPlaceName.add("p_c7");

        Condition Tu7Ct1 = new Condition(t_u7, "p_c7", TransitionCondition.NotNull);
        Condition Tu7Ct2 = new Condition(t_u7, "p_xx3", TransitionCondition.CanAddCars);
        Tu7Ct1.SetNextCondition(LogicConnector.AND, Tu7Ct2);

        GuardMapping grdTu7 = new GuardMapping();
        grdTu7.condition= Tu7Ct1;
        grdTu7.Activations.add(new Activation(t_u7, "p_c7", TransitionOperation.AddElement, "p_xx3"));
        t_u7.GuardMappingList.add(grdTu7);

        t_u7.Delay = 0;
        pn.Transitions.add(t_u7);

        // T_U3 ------------------------------------------------
        PetriTransition t_u3 = new PetriTransition(pn);
        t_u3.TransitionName = "t_u3";
        t_u3.InputPlaceName.add("p_a3");

        Condition Tu3Ct1 = new Condition(t_u3, "p_a3", TransitionCondition.NotNull);
        Condition Tu3Ct2 = new Condition(t_u3, "p_xx3", TransitionCondition.CanAddCars);
        Tu3Ct1.SetNextCondition(LogicConnector.AND, Tu3Ct2);

        GuardMapping grdTu3 = new GuardMapping();
        grdTu3.condition= Tu3Ct1;
        grdTu3.Activations.add(new Activation(t_u3, "p_a3", TransitionOperation.AddElement, "p_xx3"));
        t_u3.GuardMappingList.add(grdTu3);

        t_u3.Delay = 0;
        pn.Transitions.add(t_u3);

        // T_U10 ------------------------------------------------
        PetriTransition t_u10 = new PetriTransition(pn);
        t_u10.TransitionName = "t_u10";
        t_u10.InputPlaceName.add("p_c10");

        Condition Tu10Ct1 = new Condition(t_u10, "p_c10", TransitionCondition.NotNull);
        Condition Tu10Ct2 = new Condition(t_u10, "p_xx3", TransitionCondition.CanAddCars);
        Tu10Ct1.SetNextCondition(LogicConnector.AND, Tu10Ct2);

        GuardMapping grdTu10 = new GuardMapping();
        grdTu10.condition= Tu10Ct1;
        grdTu10.Activations.add(new Activation(t_u10, "p_c10", TransitionOperation.AddElement, "p_xx3"));
        t_u10.GuardMappingList.add(grdTu10);

        t_u10.Delay = 0;
        pn.Transitions.add(t_u10);

        // T_B3 ------------------------------------------------
        PetriTransition t_b3 = new PetriTransition(pn);
        t_b3.TransitionName = "t_b3";
        t_b3.InputPlaceName.add("p_xx3");

        Condition Tb3Ct1 = new Condition(t_b3, "p_xx3", TransitionCondition.HaveCarForMe);

        GuardMapping grdTb3 = new GuardMapping();
        grdTb3.condition= Tb3Ct1;
        grdTb3.Activations.add(new Activation(t_b3, "p_xx3", TransitionOperation.PopElementWithTarget, "p_b3"));
        t_b3.GuardMappingList.add(grdTb3);

        t_b3.Delay = 0;
        pn.Transitions.add(t_b3);


        // T_C8 ------------------------------------------------
        PetriTransition t_c8 = new PetriTransition(pn);
        t_c8.TransitionName = "t_c8";
        t_c8.InputPlaceName.add("p_xx3");

        Condition Tc8Ct1 = new Condition(t_c8, "p_xx3", TransitionCondition.HaveCarForMe);

        GuardMapping grdTc8 = new GuardMapping();
        grdTc8.condition= Tc8Ct1;
        grdTc8.Activations.add(new Activation(t_c8, "p_xx3", TransitionOperation.PopElementWithTarget, "p_c8"));
        t_c8.GuardMappingList.add(grdTc8);

        t_c8.Delay = 0;
        pn.Transitions.add(t_c8);

        // T_C9 ------------------------------------------------
        PetriTransition t_c9 = new PetriTransition(pn);
        t_c9.TransitionName = "t_c9";
        t_c9.InputPlaceName.add("p_xx3");

        Condition Tc9Ct1 = new Condition(t_c9, "p_xx3", TransitionCondition.HaveCarForMe);

        GuardMapping grdTc9 = new GuardMapping();
        grdTc9.condition= Tc9Ct1;
        grdTc9.Activations.add(new Activation(t_c9, "p_xx3", TransitionOperation.PopElementWithTarget, "p_c9"));
        t_c9.GuardMappingList.add(grdTc9);

        t_c9.Delay = 0;
        pn.Transitions.add(t_c9);



        //-------------------------------------------------------------------------------------
        //----------------------------PN Start-------------------------------------------------
        //-------------------------------------------------------------------------------------

        System.out.println("Exp1 started \n ------------------------------");
        pn.Delay = 2000;
        //pn.Start();

        PetriNetWindow frame = new PetriNetWindow(false);
        frame.petriNet = pn;
        frame.setVisible(true);
    }
}
