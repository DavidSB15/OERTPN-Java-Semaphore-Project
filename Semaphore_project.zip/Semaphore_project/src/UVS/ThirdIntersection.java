package UVS;

import Components.Activation;
import Components.Condition;
import Components.GuardMapping;
import Components.PetriNet;
import Components.PetriNetWindow;
import Components.PetriTransition;
import DataObjects.DataCar;
import DataObjects.DataCarQueue;
import DataObjects.DataString;
import DataObjects.DataTransfer;
import DataOnly.TransferOperation;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

public class ThirdIntersection
{
    public static void main(String[] args) {

        //--------------------------------------------------------------------
        //-------------------------------Lane1--------------------------------
        //--------------------------------------------------------------------

        PetriNet pn = new PetriNet();
        pn.PetriNetName = "Main Petri";
        pn.NetworkPort = 1080;

        DataCar p_a4 = new DataCar();
        p_a4.SetName("p_a4");
        pn.PlaceList.add(p_a4);

        DataCar p_a5 = new DataCar();
        p_a5.SetName("p_a5");
        pn.PlaceList.add(p_a5);


        DataCar p_b4 = new DataCar();
        p_b4.SetName("p_b4");
        pn.PlaceList.add(p_b4);

        DataCar p_b5 = new DataCar();
        p_b5.SetName("p_b5");
        pn.PlaceList.add(p_b5);


        DataTransfer p_c10s = new DataTransfer();
        p_c10s.Value = new TransferOperation("localhost", "1082" , "p_c10");
        p_c10s.SetName("p_c10s");
        pn.PlaceList.add(p_c10s);

        DataCar p_c11 = new DataCar();
        p_c11.SetName("p_c11");
        pn.PlaceList.add(p_c11);

        DataCar p_c12 = new DataCar();
        p_c12.SetName("p_c12");
        pn.PlaceList.add(p_c12);


        DataCarQueue p_x1 = new DataCarQueue();
        p_x1.Value.Size = 3;
        p_x1.SetName("p_x1");
        pn.PlaceList.add(p_x1);

        DataCarQueue p_x2 = new DataCarQueue();
        p_x2.Value.Size = 3;
        p_x2.SetName("p_x2");
        pn.PlaceList.add(p_x2);

        DataCarQueue p_x3 = new DataCarQueue();
        p_x3.Value.Size = 3;
        p_x3.SetName("p_x3");
        pn.PlaceList.add(p_x3);


        DataCarQueue p_xx4 = new DataCarQueue();
        p_xx4.Value.Size = 3;
        p_xx4.SetName("p_xx4");
        pn.PlaceList.add(p_xx4);


        DataString p_tl1 = new DataString();
        p_tl1.SetName("p_tl1");
        pn.PlaceList.add(p_tl1);

        DataString p_tl2 = new DataString();
        p_tl2.SetName("p_tl2");
        pn.PlaceList.add(p_tl2);

        DataString p_tl3 = new DataString();
        p_tl3.SetName("p_tl3");
        pn.PlaceList.add(p_tl3);


        DataTransfer op1 = new DataTransfer();
        op1.SetName("op1");
        op1.Value = new TransferOperation("localhost", "1081", "ini");
        pn.PlaceList.add(op1);

        DataTransfer op2 = new DataTransfer();
        op2.SetName("op2");
        op2.Value = new TransferOperation("localhost", "1081", "ini");
        pn.PlaceList.add(op2);

        DataTransfer op3 = new DataTransfer();
        op3.SetName("op3");
        op3.Value = new TransferOperation("localhost", "1081", "ini");
        pn.PlaceList.add(op3);

//		DataString p3 = new DataString();
//		p3.SetName("P_TL1");
//		pn.PlaceList.add(p3);

        DataString full = new DataString();
        full.SetName("full");
        full.SetValue("full");
        pn.ConstantPlaceList.add(full);


		DataString green = new DataString();
		green.SetName("green");
		green.SetValue("green");
		green.Printable= false;
		pn.ConstantPlaceList.add(green);


        // T_c10 ------------------------------------------------
        PetriTransition t_c10 = new PetriTransition(pn);
        t_c10.TransitionName = "t_c10";
        t_c10.InputPlaceName.add("p_c12");

        Condition Tc10Ct1 = new Condition(t_c10, "p_c12", TransitionCondition.NotNull);

        GuardMapping grdTc10 = new GuardMapping();
        grdTc10.condition= Tc10Ct1;
        grdTc10.Activations.add(new Activation(t_c10, "p_c12", TransitionOperation.SendOverNetwork, "p_c10s"));
        t_c10.GuardMappingList.add(grdTc10);

        t_c10.Delay = 0;
        pn.Transitions.add(t_c10);


        // T_c12 ------------------------------------------------
        PetriTransition t_c12 = new PetriTransition(pn);
        t_c12.TransitionName = "t_c12";
        t_c12.InputPlaceName.add("p_xx4");

        Condition Tc12Ct1 = new Condition(t_c12, "p_xx4", TransitionCondition.HaveCar);

        GuardMapping grdTc12 = new GuardMapping();
        grdTc12.condition= Tc12Ct1;
        grdTc12.Activations.add(new Activation(t_c12, "p_xx4", TransitionOperation.PopElementWithoutTarget, "p_c12"));
        t_c12.GuardMappingList.add(grdTc12);

        t_c12.Delay = 0;
        pn.Transitions.add(t_c12);

        // T_b4 ------------------------------------------------
        PetriTransition t_b4 = new PetriTransition(pn);
        t_b4.TransitionName = "t_b4";
        t_b4.InputPlaceName.add("p_xx4");

        Condition Tb4Ct1 = new Condition(t_b4, "p_xx4", TransitionCondition.HaveCarForMe);

        GuardMapping grdTb4 = new GuardMapping();
        grdTb4.condition = Tb4Ct1;
        grdTb4.Activations.add(new Activation(t_b4, "p_xx4", TransitionOperation.PopElementWithTarget, "p_b4"));
        t_b4.GuardMappingList.add(grdTb4);

        t_b4.Delay = 0;
        pn.Transitions.add(t_b4);


        // T_b5 ------------------------------------------------
        PetriTransition t_b5 = new PetriTransition(pn);
        t_b5.TransitionName = "t_b5";
        t_b5.InputPlaceName.add("p_xx4");

        Condition Tb5Ct1 = new Condition(t_b5, "p_xx4", TransitionCondition.HaveCarForMe);

        GuardMapping grdTb5 = new GuardMapping();
        grdTb5.condition = Tb5Ct1;
        grdTb5.Activations.add(new Activation(t_b5, "p_xx4", TransitionOperation.PopElementWithTarget, "p_b5"));
        t_b5.GuardMappingList.add(grdTb5);

        t_b5.Delay = 0;
        pn.Transitions.add(t_b5);


        // T_u4 ----------------------------------------
        PetriTransition t_u4 = new PetriTransition(pn);
        t_u4.TransitionName = "t_u4";
        t_u4.InputPlaceName.add("p_a4");
        t_u4.InputPlaceName.add("p_x2");

        Condition Tu4Ct1 = new Condition(t_u4, "p_a4", TransitionCondition.NotNull);
        Condition Tu4Ct2 = new Condition(t_u4, "p_x2", TransitionCondition.CanAddCars);
        Tu4Ct1.SetNextCondition(LogicConnector.AND, Tu4Ct2);

        GuardMapping grdTu4 = new GuardMapping();
        grdTu4.condition = Tu4Ct1;
        grdTu4.Activations.add(new Activation(t_u4, "p_a4", TransitionOperation.AddElement, "p_x2"));
        t_u4.GuardMappingList.add(grdTu4);

        Condition Tu4Ct3 = new Condition(t_u4, "p_a4", TransitionCondition.NotNull);
        Condition Tu4Ct4 = new Condition(t_u4, "p_x2", TransitionCondition.CanNotAddCars);
        Tu4Ct3.SetNextCondition(LogicConnector.AND, Tu4Ct4);

        GuardMapping grdTu4_1 = new GuardMapping();
        grdTu4_1.condition= Tu4Ct3;
        grdTu4_1.Activations.add(new Activation(t_u4, "full", TransitionOperation.SendOverNetwork, "op2"));
        grdTu4_1.Activations.add(new Activation(t_u4, "p_a4", TransitionOperation.Copy, "p_a4"));
        t_u4.GuardMappingList.add(grdTu4_1);

        t_u4.Delay = 0;
        pn.Transitions.add(t_u4);



        // T_u5 ----------------------------------------
        PetriTransition t_u5 = new PetriTransition(pn);
        t_u5.TransitionName = "t_u5";
        t_u5.InputPlaceName.add("p_a5");
        t_u5.InputPlaceName.add("p_x3");

        Condition Tu5Ct1 = new Condition(t_u4, "p_a5", TransitionCondition.NotNull);
        Condition Tu5Ct2 = new Condition(t_u4, "p_x3", TransitionCondition.CanAddCars);
        Tu5Ct1.SetNextCondition(LogicConnector.AND, Tu5Ct2);

        GuardMapping grdTu5 = new GuardMapping();
        grdTu5.condition = Tu5Ct1;
        grdTu5.Activations.add(new Activation(t_u5, "p_a5", TransitionOperation.AddElement, "p_x3"));
        t_u5.GuardMappingList.add(grdTu5);

        Condition Tu5Ct3 = new Condition(t_u5, "p_a5", TransitionCondition.NotNull);
        Condition Tu5Ct4 = new Condition(t_u5, "p_x3", TransitionCondition.CanNotAddCars);
        Tu5Ct3.SetNextCondition(LogicConnector.AND, Tu5Ct4);

        GuardMapping grdTu5_1 = new GuardMapping();
        grdTu5_1.condition= Tu5Ct3;
        grdTu5_1.Activations.add(new Activation(t_u5, "full", TransitionOperation.SendOverNetwork, "op3"));
        grdTu5_1.Activations.add(new Activation(t_u5, "p_a5", TransitionOperation.Copy, "p_a5"));
        t_u5.GuardMappingList.add(grdTu5_1);

        t_u5.Delay = 0;
        pn.Transitions.add(t_u5);


        // T_u9 ----------------------------------------
        PetriTransition t_u9 = new PetriTransition(pn);
        t_u9.TransitionName = "t_u9";
        t_u9.InputPlaceName.add("p_c11");
        t_u9.InputPlaceName.add("p_x1");

        Condition Tu9Ct1 = new Condition(t_u4, "p_c11", TransitionCondition.NotNull);
        Condition Tu9Ct2 = new Condition(t_u4, "p_x1", TransitionCondition.CanAddCars);
        Tu5Ct1.SetNextCondition(LogicConnector.AND, Tu9Ct2);

        GuardMapping grdTu9 = new GuardMapping();
        grdTu9.condition = Tu9Ct1;
        grdTu9.Activations.add(new Activation(t_u9, "p_c11", TransitionOperation.AddElement, "p_x1"));
        t_u9.GuardMappingList.add(grdTu9);

        Condition Tu9Ct3 = new Condition(t_u9, "p_c11", TransitionCondition.NotNull);
        Condition Tu9Ct4 = new Condition(t_u9, "p_x1", TransitionCondition.CanNotAddCars);
        Tu9Ct3.SetNextCondition(LogicConnector.AND, Tu9Ct4);

        GuardMapping grdTu9_1 = new GuardMapping();
        grdTu9_1.condition= Tu9Ct3;
        grdTu9_1.Activations.add(new Activation(t_u9, "full", TransitionOperation.SendOverNetwork, "op1"));
        grdTu9_1.Activations.add(new Activation(t_u9, "p_c11", TransitionOperation.Copy, "p_c11"));
        t_u9.GuardMappingList.add(grdTu9_1);

        t_u9.Delay = 0;
        pn.Transitions.add(t_u9);


        // Te1 ------------------------------------------------
        PetriTransition t_e1 = new PetriTransition(pn);
        t_e1.TransitionName = "t_e1";
        t_e1.InputPlaceName.add("p_x1");
        t_e1.InputPlaceName.add("p_tl1");

        Condition Te1Ct1 = new Condition(t_e1, "p_tl1", TransitionCondition.Equal, "green");
        Condition Te1Ct2 = new Condition(t_e1, "p_x1", TransitionCondition.HaveCar);
        Te1Ct1.SetNextCondition(LogicConnector.AND, Te1Ct2);

        GuardMapping grdTe1 = new GuardMapping();
        grdTe1.condition = Te1Ct1;
        grdTe1.Activations.add(new Activation(t_e1, "p_x1", TransitionOperation.PopElementWithoutTargetToQueue, "p_xx4"));
        grdTe1.Activations.add(new Activation(t_e1, "p_tl1", TransitionOperation.Move, "p_tl1"));
        t_e1.GuardMappingList.add(grdTe1);

        t_e1.Delay = 0;
        pn.Transitions.add(t_e1);


        // Te2 ------------------------------------------------
        PetriTransition t_e2 = new PetriTransition(pn);
        t_e2.TransitionName = "t_e2";
        t_e2.InputPlaceName.add("p_x2");
        t_e2.InputPlaceName.add("p_tl2");

        Condition Te2Ct1 = new Condition(t_e2, "p_tl2", TransitionCondition.Equal, "green");
        Condition Te2Ct2 = new Condition(t_e2, "p_x2", TransitionCondition.HaveCar);
        Te2Ct1.SetNextCondition(LogicConnector.AND, Te2Ct2);

        GuardMapping grdTe2 = new GuardMapping();
        grdTe2.condition = Te2Ct1;
        grdTe2.Activations.add(new Activation(t_e2, "p_x2", TransitionOperation.PopElementWithoutTargetToQueue, "p_xx4"));
        grdTe2.Activations.add(new Activation(t_e2, "p_tl2", TransitionOperation.Move, "p_tl2"));
        t_e2.GuardMappingList.add(grdTe2);

        t_e2.Delay = 0;
        pn.Transitions.add(t_e2);


        // Te3 ------------------------------------------------
        PetriTransition t_e3 = new PetriTransition(pn);
        t_e3.TransitionName = "t_e3";
        t_e3.InputPlaceName.add("p_x3");
        t_e3.InputPlaceName.add("p_tl3");

        Condition Te3Ct1 = new Condition(t_e3, "p_tl3", TransitionCondition.Equal, "green");
        Condition Te3Ct2 = new Condition(t_e3, "p_x3", TransitionCondition.HaveCar);
        Te3Ct1.SetNextCondition(LogicConnector.AND, Te3Ct2);

        GuardMapping grdTe3 = new GuardMapping();
        grdTe3.condition = Te3Ct1;
        grdTe3.Activations.add(new Activation(t_e3, "p_x3", TransitionOperation.PopElementWithoutTargetToQueue, "p_xx4"));
        grdTe3.Activations.add(new Activation(t_e3, "p_tl3", TransitionOperation.Move, "p_tl3"));
        t_e3.GuardMappingList.add(grdTe3);

        t_e3.Delay = 0;
        pn.Transitions.add(t_e3);


        //-------------------------------------------------------------------------------------
        //----------------------------PN Start-------------------------------------------------
        //-------------------------------------------------------------------------------------

        System.out.println("Exp1 started \n ------------------------------");
        pn.Delay = 2000;
        //pn.Start();

        PetriNetWindow frame = new PetriNetWindow(false);
        frame.petriNet = pn;
        frame.setVisible(true);
    }
}
