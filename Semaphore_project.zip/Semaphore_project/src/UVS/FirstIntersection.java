package UVS;

import Components.Activation;
import Components.Condition;
import Components.GuardMapping;
import Components.PetriNet;
import Components.PetriNetWindow;
import Components.PetriTransition;
import DataObjects.DataCar;
import DataObjects.DataCarQueue;
import DataObjects.DataString;
import DataObjects.DataTransfer;
import DataOnly.TransferOperation;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

public class FirstIntersection {
	public static void main(String[] args) {
		
		//---------------------------------------------------------------------------------
		//-------------------------------First Intersection--------------------------------
		//---------------------------------------------------------------------------------
		
		PetriNet pn = new PetriNet();
		pn.PetriNetName = "Main Petri";
		pn.NetworkPort = 1082;
		
		DataCar p_a1 = new DataCar();
		p_a1.SetName("p_a1");
		pn.PlaceList.add(p_a1);

		DataCar p_a2 = new DataCar();
		p_a2.SetName("p_a2");
		pn.PlaceList.add(p_a2);

		DataCar p_b1 = new DataCar();
		p_b1.SetName("p_b1");
		pn.PlaceList.add(p_b1);

		DataCar p_b2 = new DataCar();
		p_b2.SetName("p_b2");
		pn.PlaceList.add(p_b2);

		DataCar p_c1 = new DataCar();
		p_c1.SetName("p_c1");
		pn.PlaceList.add(p_c1);

		DataCar p_c2 = new DataCar();
		p_c2.SetName("p_c2");
		pn.PlaceList.add(p_c2);

		DataCar p_c3 = new DataCar();
		p_c3.SetName("p_c3");
		pn.PlaceList.add(p_c3);

		DataCar p_c4 = new DataCar();
		p_c4.SetName("p_c4");
		pn.PlaceList.add(p_c4);

		DataCar p_c5 = new DataCar();
		p_c5.SetName("p_c5");
		pn.PlaceList.add(p_c5);

		DataCar p_c6 = new DataCar();
		p_c6.SetName("p_c6");
		pn.PlaceList.add(p_c6);


		DataCarQueue p_xx1 = new DataCarQueue();
		p_xx1.Value.Size = 3;
		p_xx1.SetName("p_xx1");
		pn.PlaceList.add(p_xx1);

		DataCarQueue p_xx2 = new DataCarQueue();
		p_xx2.Value.Size = 3;
		p_xx2.SetName("p_xx2");
		pn.PlaceList.add(p_xx2);

		DataString full = new DataString();
		full.SetName("full");
		full.SetValue("full");
		pn.ConstantPlaceList.add(full);
		
		// T_U1 ------------------------------------------------
		PetriTransition t_u1 = new PetriTransition(pn);
		t_u1.TransitionName = "t_u1";
		t_u1.InputPlaceName.add("p_a1");

		Condition Tu1Ct1 = new Condition(t_u1, "p_a1", TransitionCondition.NotNull);
		Condition Tu1Ct2 = new Condition(t_u1, "p_xx1", TransitionCondition.CanAddCars);
		Tu1Ct1.SetNextCondition(LogicConnector.AND, Tu1Ct2);

		GuardMapping grdTu1 = new GuardMapping();
		grdTu1.condition= Tu1Ct1;
		grdTu1.Activations.add(new Activation(t_u1, "p_a1", TransitionOperation.AddElement, "p_xx1"));
		t_u1.GuardMappingList.add(grdTu1);

		t_u1.Delay = 0;
		pn.Transitions.add(t_u1);

		// T_U2 ------------------------------------------------
		PetriTransition t_u2 = new PetriTransition(pn);
		t_u2.TransitionName = "t_u2";
		t_u2.InputPlaceName.add("p_a2");

		Condition Tu2Ct1 = new Condition(t_u2, "p_a2", TransitionCondition.NotNull);
		Condition Tu2Ct2 = new Condition(t_u2, "p_xx1", TransitionCondition.CanAddCars);
		Tu1Ct1.SetNextCondition(LogicConnector.AND, Tu2Ct2);

		GuardMapping grdTu2 = new GuardMapping();
		grdTu2.condition= Tu2Ct1;
		grdTu2.Activations.add(new Activation(t_u2, "p_a2", TransitionOperation.AddElement, "p_xx1"));
		t_u2.GuardMappingList.add(grdTu2);

		t_u2.Delay = 0;
		pn.Transitions.add(t_u2);

		// T_U6 ------------------------------------------------
		PetriTransition t_u6 = new PetriTransition(pn);
		t_u6.TransitionName = "t_u6";
		t_u6.InputPlaceName.add("p_c2");

		Condition Tu6Ct1 = new Condition(t_u6, "p_c2", TransitionCondition.NotNull);
		Condition Tu6Ct2 = new Condition(t_u6, "p_xx1", TransitionCondition.CanAddCars);
		Tu6Ct1.SetNextCondition(LogicConnector.AND, Tu6Ct2);

		GuardMapping grdTu6 = new GuardMapping();
		grdTu6.condition= Tu6Ct1;
		grdTu6.Activations.add(new Activation(t_u6, "p_c2", TransitionOperation.AddElement, "p_xx1"));
		t_u6.GuardMappingList.add(grdTu6);

		t_u6.Delay = 0;
		pn.Transitions.add(t_u6);

		// T_U8 ------------------------------------------------
		PetriTransition t_u8 = new PetriTransition(pn);
		t_u8.TransitionName = "t_u8";
		t_u8.InputPlaceName.add("p_c6");

		Condition Tu8Ct1 = new Condition(t_u6, "p_c6", TransitionCondition.NotNull);
		Condition Tu8Ct2 = new Condition(t_u6, "p_xx2", TransitionCondition.CanAddCars);
		Tu8Ct1.SetNextCondition(LogicConnector.AND, Tu8Ct2);

		GuardMapping grdTu8 = new GuardMapping();
		grdTu8.condition= Tu8Ct1;
		grdTu8.Activations.add(new Activation(t_u8, "p_c6", TransitionOperation.AddElement, "p_xx2"));
		t_u8.GuardMappingList.add(grdTu8);

		t_u8.Delay = 0;
		pn.Transitions.add(t_u8);

		// T_B1 ------------------------------------------------
		PetriTransition t_b1 = new PetriTransition(pn);
		t_b1.TransitionName = "t_b1";
		t_b1.InputPlaceName.add("p_xx1");

		Condition Tb1Ct1 = new Condition(t_b1, "p_xx1", TransitionCondition.HaveCarForMe);

		GuardMapping grdTb1 = new GuardMapping();
		grdTb1.condition= Tb1Ct1;
		grdTb1.Activations.add(new Activation(t_b1, "p_xx1", TransitionOperation.PopElementWithTarget, "p_b1"));
		t_b1.GuardMappingList.add(grdTb1);

		t_b1.Delay = 0;
		pn.Transitions.add(t_b1);

		// T_B2 ------------------------------------------------
		PetriTransition t_b2 = new PetriTransition(pn);
		t_b2.TransitionName = "t_b2";
		t_b2.InputPlaceName.add("p_xx2");

		Condition Tb2Ct1 = new Condition(t_b2, "p_xx2", TransitionCondition.HaveCarForMe);

		GuardMapping grdTb2 = new GuardMapping();
		grdTb2.condition= Tb2Ct1;
		grdTb2.Activations.add(new Activation(t_b2, "p_xx2", TransitionOperation.PopElementWithTarget, "p_b2"));
		t_b2.GuardMappingList.add(grdTb2);

		t_b2.Delay = 0;
		pn.Transitions.add(t_b2);

		// T_C1 ------------------------------------------------
		PetriTransition t_c1 = new PetriTransition(pn);
		t_c1.TransitionName = "t_c1";
		t_c1.InputPlaceName.add("p_xx1");

		Condition Tc1Ct1 = new Condition(t_c1, "p_xx1", TransitionCondition.HaveCar);

		GuardMapping grdTc1 = new GuardMapping();
		grdTc1.condition= Tc1Ct1;
		grdTc1.Activations.add(new Activation(t_c1, "p_xx1", TransitionOperation.PopElementWithoutTarget, "p_c1"));
		t_c1.GuardMappingList.add(grdTc1);

		t_c1.Delay = 0;
		pn.Transitions.add(t_c1);

		// T_C4 ------------------------------------------------
		PetriTransition t_c4 = new PetriTransition(pn);
		t_c4.TransitionName = "t_c4";
		t_c4.InputPlaceName.add("p_xx2");

		Condition Tc4Ct1 = new Condition(t_c4, "p_xx2", TransitionCondition.HaveCar);

		GuardMapping grdTc4 = new GuardMapping();
		grdTc4.condition= Tc4Ct1;
		grdTc4.Activations.add(new Activation(t_c4, "p_xx2", TransitionOperation.PopElementWithoutTarget, "p_c4"));
		t_c4.GuardMappingList.add(grdTc4);

		t_c4.Delay = 0;
		pn.Transitions.add(t_c4);

		// T_C2 ------------------------------------------------
		PetriTransition t_c2 = new PetriTransition(pn);
		t_c2.TransitionName = "t_c2";
		t_c2.InputPlaceName.add("p_c4");

		Condition Tc2Ct1 = new Condition(t_c2, "p_c4", TransitionCondition.NotNull);

		GuardMapping grdTc2 = new GuardMapping();
		grdTc2.condition= Tc2Ct1;
		grdTc2.Activations.add(new Activation(t_c2, "p_c4", TransitionOperation.Move, "p_c2"));
		t_c2.GuardMappingList.add(grdTc2);

		t_c2.Delay = 0;
		pn.Transitions.add(t_c2);

		// T_C3 ------------------------------------------------
		PetriTransition t_c3 = new PetriTransition(pn);
		t_c3.TransitionName = "t_c3";
		t_c3.InputPlaceName.add("p_c1");

		Condition Tc3Ct1 = new Condition(t_c3, "p_c1", TransitionCondition.NotNull);

		GuardMapping grdTc3 = new GuardMapping();
		grdTc3.condition= Tc3Ct1;
		grdTc3.Activations.add(new Activation(t_c3, "p_c1", TransitionOperation.Move, "p_c3"));
		t_c3.GuardMappingList.add(grdTc3);

		t_c3.Delay = 0;
		pn.Transitions.add(t_c3);

		// T_C5 ------------------------------------------------
		PetriTransition t_c5 = new PetriTransition(pn);
		t_c5.TransitionName = "t_c5";
		t_c5.InputPlaceName.add("p_c3");

		Condition Tc5Ct1 = new Condition(t_c5, "p_c3", TransitionCondition.NotNull);

		GuardMapping grdTc5 = new GuardMapping();
		grdTc5.condition= Tc5Ct1;
		grdTc5.Activations.add(new Activation(t_c5, "p_c3", TransitionOperation.Move, "p_c5"));
		t_c5.GuardMappingList.add(grdTc5);

		t_c5.Delay = 0;
		pn.Transitions.add(t_c5);

		//----------------------------------------------------------------------------------
		//-------------------------------Second Intersection--------------------------------
		//----------------------------------------------------------------------------------

		DataCar p_a3 = new DataCar();
		p_a3.SetName("p_a3");
		pn.PlaceList.add(p_a3);

		DataCar p_b3 = new DataCar();
		p_b3.SetName("p_b3");
		pn.PlaceList.add(p_b3);

		DataCar p_c7 = new DataCar();
		p_c7.SetName("p_c7");
		pn.PlaceList.add(p_c7);

		DataCar p_c8 = new DataCar();
		p_c8.SetName("p_c8");
		pn.PlaceList.add(p_c8);

		DataCar p_c9 = new DataCar();
		p_c9.SetName("p_c9");
		pn.PlaceList.add(p_c9);

		DataCar p_c10 = new DataCar();
		p_c10.SetName("p_c10");
		pn.PlaceList.add(p_c10);

		DataTransfer p_c11s = new DataTransfer();
		p_c11s.Value = new TransferOperation("localhost", "1080" , "p_c11");
		p_c11s.SetName("p_c11s");
		pn.PlaceList.add(p_c11s);


		DataCarQueue p_xx3 = new DataCarQueue();
		p_xx3.Value.Size = 3;
		p_xx3.SetName("p_xx3");
		pn.PlaceList.add(p_xx3);



		// T_U7 ------------------------------------------------
		PetriTransition t_u7 = new PetriTransition(pn);
		t_u7.TransitionName = "t_u7";
		t_u7.InputPlaceName.add("p_c7");

		Condition Tu7Ct1 = new Condition(t_u7, "p_c7", TransitionCondition.NotNull);
		Condition Tu7Ct2 = new Condition(t_u7, "p_xx3", TransitionCondition.CanAddCars);
		Tu7Ct1.SetNextCondition(LogicConnector.AND, Tu7Ct2);

		GuardMapping grdTu7 = new GuardMapping();
		grdTu7.condition= Tu7Ct1;
		grdTu7.Activations.add(new Activation(t_u7, "p_c7", TransitionOperation.AddElement, "p_xx3"));
		t_u7.GuardMappingList.add(grdTu7);

		t_u7.Delay = 0;
		pn.Transitions.add(t_u7);

		// T_U3 ------------------------------------------------
		PetriTransition t_u3 = new PetriTransition(pn);
		t_u3.TransitionName = "t_u3";
		t_u3.InputPlaceName.add("p_a3");

		Condition Tu3Ct1 = new Condition(t_u3, "p_a3", TransitionCondition.NotNull);
		Condition Tu3Ct2 = new Condition(t_u3, "p_xx3", TransitionCondition.CanAddCars);
		Tu3Ct1.SetNextCondition(LogicConnector.AND, Tu3Ct2);

		GuardMapping grdTu3 = new GuardMapping();
		grdTu3.condition= Tu3Ct1;
		grdTu3.Activations.add(new Activation(t_u3, "p_a3", TransitionOperation.AddElement, "p_xx3"));
		t_u3.GuardMappingList.add(grdTu3);

		t_u3.Delay = 0;
		pn.Transitions.add(t_u3);

		// T_U10 ------------------------------------------------
		PetriTransition t_u10 = new PetriTransition(pn);
		t_u10.TransitionName = "t_u10";
		t_u10.InputPlaceName.add("p_c10");

		Condition Tu10Ct1 = new Condition(t_u10, "p_c10", TransitionCondition.NotNull);
		Condition Tu10Ct2 = new Condition(t_u10, "p_xx3", TransitionCondition.CanAddCars);
		Tu10Ct1.SetNextCondition(LogicConnector.AND, Tu10Ct2);

		GuardMapping grdTu10 = new GuardMapping();
		grdTu10.condition= Tu10Ct1;
		grdTu10.Activations.add(new Activation(t_u10, "p_c10", TransitionOperation.AddElement, "p_xx3"));
		t_u10.GuardMappingList.add(grdTu10);

		t_u10.Delay = 0;
		pn.Transitions.add(t_u10);

		// T_B3 ------------------------------------------------
		PetriTransition t_b3 = new PetriTransition(pn);
		t_b3.TransitionName = "t_b3";
		t_b3.InputPlaceName.add("p_xx3");

		Condition Tb3Ct1 = new Condition(t_b3, "p_xx3", TransitionCondition.HaveCarForMe);

		GuardMapping grdTb3 = new GuardMapping();
		grdTb3.condition= Tb3Ct1;
		grdTb3.Activations.add(new Activation(t_b3, "p_xx3", TransitionOperation.PopElementWithTarget, "p_b3"));
		t_b3.GuardMappingList.add(grdTb3);

		t_b3.Delay = 0;
		pn.Transitions.add(t_b3);

		// T_C6 ------------------------------------------------
		PetriTransition t_c6 = new PetriTransition(pn);
		t_c6.TransitionName = "t_c6";
		t_c6.InputPlaceName.add("p_c8");

		Condition Tc6Ct1 = new Condition(t_c6, "p_c8", TransitionCondition.NotNull);

		GuardMapping grdTc6 = new GuardMapping();
		grdTc6.condition= Tc6Ct1;
		grdTc6.Activations.add(new Activation(t_c6, "p_c8", TransitionOperation.Move, "p_c6"));
		t_c6.GuardMappingList.add(grdTc6);

		t_c6.Delay = 0;
		pn.Transitions.add(t_c6);

		// T_C7 ------------------------------------------------
		PetriTransition t_c7 = new PetriTransition(pn);
		t_c7.TransitionName = "t_c7";
		t_c7.InputPlaceName.add("p_c5");

		Condition Tc7Ct1 = new Condition(t_c7, "p_c5", TransitionCondition.NotNull);

		GuardMapping grdTc7 = new GuardMapping();
		grdTc7.condition= Tc7Ct1;
		grdTc7.Activations.add(new Activation(t_c7, "p_c5", TransitionOperation.Move, "p_c7"));
		t_c7.GuardMappingList.add(grdTc7);

		t_c7.Delay = 0;
		pn.Transitions.add(t_c7);


		// T_C8 ------------------------------------------------
		PetriTransition t_c8 = new PetriTransition(pn);
		t_c8.TransitionName = "t_c8";
		t_c8.InputPlaceName.add("p_xx3");

		Condition Tc8Ct1 = new Condition(t_c8, "p_xx3", TransitionCondition.HaveCarForMe);

		GuardMapping grdTc8 = new GuardMapping();
		grdTc8.condition= Tc8Ct1;
		grdTc8.Activations.add(new Activation(t_c8, "p_xx3", TransitionOperation.PopElementWithTarget, "p_c8"));
		t_c8.GuardMappingList.add(grdTc8);

		t_c8.Delay = 0;
		pn.Transitions.add(t_c8);

		// T_C9 ------------------------------------------------
		PetriTransition t_c9 = new PetriTransition(pn);
		t_c9.TransitionName = "t_c9";
		t_c9.InputPlaceName.add("p_xx3");

		Condition Tc9Ct1 = new Condition(t_c9, "p_xx3", TransitionCondition.HaveCarForMe);

		GuardMapping grdTc9 = new GuardMapping();
		grdTc9.condition= Tc9Ct1;
		grdTc9.Activations.add(new Activation(t_c9, "p_xx3", TransitionOperation.PopElementWithTarget, "p_c9"));
		t_c9.GuardMappingList.add(grdTc9);

		t_c9.Delay = 0;
		pn.Transitions.add(t_c9);


		// T_c11 ------------------------------------------------
		PetriTransition t_c11 = new PetriTransition(pn);
		t_c11.TransitionName = "t_c11";
		t_c11.InputPlaceName.add("p_c9");

		Condition Tc11Ct1 = new Condition(t_c11, "p_c9", TransitionCondition.NotNull);

		GuardMapping grdTc11 = new GuardMapping();
		grdTc11.condition= Tc11Ct1;
		grdTc11.Activations.add(new Activation(t_c11, "p_c9", TransitionOperation.SendOverNetwork, "p_c11s"));
		t_c11.GuardMappingList.add(grdTc11);

		t_c11.Delay = 0;
		pn.Transitions.add(t_c11);

		//-------------------------------------------------------------------------------------
		//----------------------------PN Start-------------------------------------------------
		//-------------------------------------------------------------------------------------

		System.out.println("Exp1 started \n ------------------------------");
		pn.Delay = 2000;
		//pn.Start();
		
		PetriNetWindow frame = new PetriNetWindow(false);
		frame.petriNet = pn;
		frame.setVisible(true);
	}
}
