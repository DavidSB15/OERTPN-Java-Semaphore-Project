package Enumerations;

import java.io.Serializable;

public enum LogicConnector implements Serializable {
	AND, OR
}
